import { Bricolage_Grotesque, Manrope } from "next/font/google";

// Table and Plate titles
export const bricolage = Bricolage_Grotesque({
  subsets: ["latin"],
  weight: ["600", "700", "800"],
  variable: "--font-bricolage",
  display: "swap",
});

// Everything else. 500 is loaded because shadcn components use font-medium.
export const manrope = Manrope({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-manrope",
  display: "swap",
});

// app/layout.tsx
//   import { bricolage, manrope } from "./fonts";
//   <html lang="en" className={`${bricolage.variable} ${manrope.variable}`}>
//
// Also export this from the root layout so the mobile keyboard resizes the page
// instead of covering the composer:
//   export const viewport = {
//     width: "device-width",
//     initialScale: 1,
//     viewportFit: "cover",
//     interactiveWidget: "resizes-content",
//   };
