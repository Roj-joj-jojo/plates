# Plates layout, responsive and behaviour rules

## Spacing (4px base; Tailwind's default scale already matches)
| Thing | Value |
|---|---|
| Page gutter, mobile (below 768px) | 16px (`px-4`) |
| Page gutter, thread and wider | 24px minimum (`px-6`) |
| Thread column | centred, `max-w-thread` (720px) |
| Gap between messages | 12px (`gap-3`) on mobile and desktop. The 44px header row adds visual space, so the gap is smaller than the 22 to 24px of the mockups |
| Avatar | 36px (`size-9`), circle, 12px from the text column |
| Header row (name, username, time, actions) | 44px tall, because it holds the real 44px button |
| Message body after header | 0 gap; attachment after body 8px |
| Plate and Request card | padding 12px 14px, radius `rounded-lg` (6px), background `card` |
| Photo gap | 4px; tiles at least 72px; single photo up to 320px wide |
| Unread divider | 8px above and below; 2px butter line with a butter chip |
| Composer | field min 44px, grows to 6 lines (about 144px) then scrolls; padding 12px 16px plus the bottom safe-area inset; attach and Send are 44px |

## Layout
- Below 768px: header (Table name, Members, Search, Photos), thread, composer, bottom tab bar (six destinations, 13px labels). Members and Photos open in a `Sheet`.
- 768px and up (`thread:` breakpoint): left nav rail 200px; thread and composer centred in the remaining column.
- 1200px and up (`wide:` breakpoint): right panel 260px with Members and Photos.
- Use `h-dvh`, not `h-screen`. The thread is the scrolling element (`overflow-y-auto`); the header, composer and tab bar do not scroll.

## Long and awkward content
- Names: `truncate` with a `title`. The name column is capped at 60% of the header; the username shrinks first. Never wrap names onto a second line.
- Message text: `whitespace-pre-wrap [overflow-wrap:anywhere]` so unbroken links and long strings wrap instead of widening the page. Link text may break anywhere; keep `href` intact.
- Shared Plates and Requests: titles wrap, never truncate. Metadata lines wrap.
- Photos: see `photo-grid.tsx`. 1, 2 or 3 photos in one row; four tiles in two columns until the thread column is 352px wide, then four columns, so tiles stay at least 72px. "+N" sits on the last tile. All photos need alt text.
- Test with a 40-character name, a 60-character username, and a 200-character URL with no spaces.

## Mobile keyboard
- Wrap the Table screen in `TableShell`. It sizes and positions the screen to the visual viewport (`--vvh`, `--vv-top` from `use-visual-viewport.ts`), so the composer sits directly above the keyboard on iOS Safari, where the keyboard does not resize the layout viewport. The page itself does not scroll; only the thread does. The composer is a normal row of the shell, never `position: fixed`.
- Export `viewport` with `interactiveWidget: "resizes-content"` for Chrome and Android, and `viewportFit: "cover"` so safe-area insets work. Composer bottom padding includes `env(safe-area-inset-bottom)`.
- `use-thread-scroll.ts` keeps a reader who was at the bottom at the bottom when the keyboard opens, the composer grows, or images load.
- Mention suggestions open above the field, at most 40dvh tall, with 44px rows.
- This approach is the standard one but has not been run on devices here. Before release, test on a real iPhone (Safari) and an Android phone (Chrome), each with: keyboard open and a one-line draft; a six-line draft; a mention list open; rotation; a message arriving while the keyboard is open; and the thread scrolled up.

## Focus (one treatment)
- 3px outline in `ring` (ink), 2px offset, from the global rule in `globals.css`. It also zeroes shadcn ring shadows so nothing stacks.
- On dark surfaces (the ink header) add `data-surface="dark"`; the outline becomes white. Contrast: ink on white 18.45:1, white on ink 18.45:1.
- Never show a heavy outline as a control's normal look.

## Live updates
- Never remount the composer or reset its draft. Re-rendering is normal in React and is fine. The composer owns its draft state, is memoised, and clears it only after a send succeeds. Do not key it on message data.
- Sending: the field is read-only while a send is in flight, so nothing typed during the wait can be lost. A ref guard blocks duplicate submissions. On success the text clears. On failure (a resolved `{ ok: false }` or a thrown error) the text stays, the error shows, and Send retries with the same `clientId`, which the server should treat as an idempotency key.
- Mentions: the selected index is clamped when the list shrinks and reset when the query changes. Escape dismisses the list for that mention. The field is a combobox (`aria-controls`, `aria-activedescendant`), and the current person is excluded from suggestions. If Plates already has its own self-exclusion rule, keep it and remove the filter in `composer.tsx`.
- Editing: the editor is mounted only while editing and starts from the current message, so cancelled text never returns and a later edit never starts from stale text. A live update does not overwrite what the person is typing. A failed save keeps the editor open with an error.
- Scroll: `use-thread-scroll.ts` takes message ids, not a count, so appended messages, older history loaded at the top, and a replaced window are told apart. It handles first positioning (first unread or the mentioned message, else the bottom), composer growth and image loading with ResizeObserver, and keeps the reader's place when older history loads (Safari lacks CSS scroll anchoring). Give photos fixed aspect ratios so they reserve space.
- If the reader is within 80px of the bottom, keep them pinned. If they have scrolled up, do not move the view; show "N new messages" with a jump-to-latest button. Their own sent message always scrolls to the bottom.
- The unread divider sits before the first unread message and stays until the Table is left or the reader acknowledges it.
- Announce new content to screen readers with a polite live region ("2 new messages"), not by moving focus.
- Mention notifications open the Table at the specific message or discussion (pass it as `initialTargetId`), and mark it with a short `bg-secondary` highlight (respect reduced motion).

## Permissions (unchanged)
Authors edit and remove their own contributions. Admins remove within their Table and never edit another person's words. Only a Plate's author can unpublish the original. Removing a Table share keeps the Plate. Unpublishing keeps Menu copies. Replies stay readable after a Request or share is removed; new replies stop (`Composer` `closedReason`).

## v2.2 implementation clarification
The scroll hook now restores a visible message and its offset, including mixed history/live batches, with native anchoring disabled. See INTEGRATION.md for captureBeforeUpdate, arrivingIds, navigationTargetId/navigationKey, missing-target loading, and retry attachment identity. These supersede the earlier implementation description.
