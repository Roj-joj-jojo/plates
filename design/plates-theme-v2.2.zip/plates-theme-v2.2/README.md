# Plates theme v2.2: Clean Tomato AA for Tailwind 4 and shadcn/ui

Light only for the MVP. No dark palette is defined, and `dark:` classes are not used.
Radii of 2, 4 and 6px are intentionally squarer than the first mockups (this was a deliberate request).

## Files
| File | Goes to |
|---|---|
| `app/globals.css` | Merge the reviewed theme into your existing global CSS. Tailwind 4 CSS-first config: `:root` values, `@theme inline` mappings (colours, radii, fonts, type), base layer, focus rule. No `tailwind.config.ts` is needed. |
| `app/fonts.ts` | New. Loads Bricolage Grotesque (600, 700, 800) and Manrope (400, 500, 600, 700). |
| `components/ui/button.tsx` | Replaces the shadcn button. Every size is at least 44px. |
| `components/ui/icon-button.tsx` | New. A real 44px button with a 28px visual. |
| `components/plates/*` | New. Message tile, actions menu, removal confirmations, photo grid, composer. |
| `components/plates/table-shell.tsx` | New. Whole-screen frame sized to the visible area, for the mobile keyboard. |
| `hooks/use-thread-scroll.ts` | New. Reading position by message id: arrivals, older history, first load, resizes. |
| `hooks/use-visual-viewport.ts` | New. Publishes `--vvh` and `--vv-top` for TableShell. |
| `RULES.md` | Spacing, responsive layout, long content, mobile keyboard, focus, live updates. |
| `STATES.md` | Every state with its copy and the component that shows it. |

## Install
1. `npm i tw-animate-css` (the Tailwind 4 replacement for tailwindcss-animate). Only install dependencies after owner approval. Preserve existing config and dependencies until their integration is reviewed.
2. Merge into `app/globals.css`, preserving unrelated styles. If your shadcn setup already has one, keep your own `@import` lines and merge the `:root`, `@theme inline` and `@layer base` blocks.
3. Add `app/fonts.ts`, then put both font variables on `<html>` and export the `viewport` (see the comments in that file).
4. Install the shadcn components used: `button` (overwrite with this one), `textarea`, `avatar`, `dropdown-menu`, `alert-dialog`, `sonner`, `sheet`, `skeleton`, `alert`, `card`, `badge`, `tooltip`, `tabs`, `separator`, `scroll-area`.
5. Do not add `ring`, `outline-none` or `focus-visible:` classes to Plates components. Stock shadcn ones are neutralised by the global rule.

## One set of values
All colours are hex, used directly. There are no HSL or OKLCH copies to drift. Contrast below is calculated from these exact values.

| Pair | Ratio |
|---|---|
| foreground on background | 18.45:1 |
| foreground on card | 17.22:1 |
| foreground on tint | 15.11:1 |
| muted-foreground on background | 7.80:1 |
| muted-foreground on card | 7.28:1 |
| muted-foreground on tint | 6.39:1 |
| primary-foreground on primary | 5.67:1 |
| primary-foreground on primary-hover | 7.36:1 |
| link on background | 6.51:1 |
| link on card | 6.07:1 |
| link on tint | 5.33:1 |
| destructive text on background | 8.22:1 |
| destructive-foreground on destructive | 8.22:1 |
| success-foreground on success | 7.79:1 |
| unread-foreground on unread | 11.75:1 |
| ring on background (3:1 needed) | 18.45:1 |
| ring on card (3:1 needed) | 17.22:1 |
| ring-on-dark on ink header (3:1 needed) | 18.45:1 |
| input border on background (3:1 needed) | 7.80:1 |
| primary on background (button edge, 3:1) | 5.67:1 |

Text needs 4.5:1 and interface edges and focus indicators 3:1. Everything above passes. The earlier note of 6.5:1 for link text applied to link on white. Link on tomato tint is 5.33:1, and on card 6.07:1.

## Colour roles (one job each)
- `primary`: primary actions only (Save to Menu, Send, Share a Plate). Hover is `primary-hover`.
- `unread`: unread markers and the "new" divider. Always with `unread-foreground` text.
- `success`: saved and sent confirmations.
- `destructive`: Remove, Unpublish, Remove as Admin. Never use `primary` for these.
- `link`: links, @mentions, small labels on tinted surfaces.
- `card` / `muted` (#FFF5F2): Plate and Request previews. `secondary` / `accent` (#FDE3DC): avatar chips, mention highlight, selected nav, menu hover.
- `border` (#F2CFC6): hairline separators only. `input` (#5E4F4A): borders of inputs and outlined controls.
- The page, nav rail, side panel and composer stay on `background` (white).

## Type
| Class | Spec |
|---|---|
| `font-display text-table-title` | Bricolage 700, 24/30: Table name |
| `font-display text-plate-title` | Bricolage 700, 18/24: Plate titles |
| `font-semibold` at body size | Manrope 600, 16/24: author names |
| body (default) | Manrope 400, 16/24: messages |
| `text-meta text-muted-foreground` | Manrope 400, 13/18: usernames, times, Edited |
| `text-label text-link` | Manrope 700, 13/18, +0.06em: Plate and Request labels |

`text-xs` is mapped to 13px in the theme, so stock components that use it still meet the minimum. `text-sm` is 14px. Request titles are Manrope bold.

## What changed from v1
Tailwind 4 theme instead of a Tailwind 3 config; a single hex set; Manrope 500 loaded; one focus treatment with a dark-surface variant; 44px enforced in components; the live-update rule rewritten; the missing states and the spacing and responsive rules added.

## v2.2
See INTEGRATION.md for send locking, existing server retry mapping, visible-message scroll anchoring and explicit same-Table mention navigation. This ZIP is a reference package; merge only reviewed changes during a separately approved app integration.
