# v2.2 fixes and integration notes

This is a reference package, not installed app code. Preserve the tested Plates data paths.

## Send lock

Mention suggestions are hidden during sending. Their click/insertion handler and field
change/keyboard handlers also check the synchronous in-flight ref, including stale events
before React re-renders. A failed send retains the text and the attempt ID; editing text
starts a new attempt. Changing submissionKey starts a new attempt even for unchanged text.
Use submissionKey for the selected attachment signature (selection identity, not transient
upload progress). Attachment selection is frozen during sending.

## Existing server retry protection

Plates already uses post_message with p_client_request_id. The local migration
20261006000200_plates_timeline.sql scopes retries to author + Table + request ID, compares
a fingerprint of kind/Table/Plate/body/links/attachment IDs, and returns the original entry
for a matching retry. No new schema or server retry mechanism is included here.

During integration, map Composer onSend(text, clientId) to the existing post_message RPC:
pass clientId as p_client_request_id, text as p_body, and the existing prepared attachment
IDs as p_attachment_ids. Return { ok: false, error } for RPC errors; return { ok: true }
only after successful completion. Reuse prepared uploaded attachment IDs on retry, as the
current PostTableMessageForm does. Do not re-upload the same selection under new IDs when
retrying an ambiguous result; the server fingerprint includes those IDs. Text or attachment
changes must produce a new request ID. Keep existing photo-only posting when composing the
final app integration; this text-first reference Composer does not replace that data flow.

Source inspection confirmed the existing protection; a new database acceptance test was
not run. Acceptance scenario: persist a message, drop its response, retry identical payload
and ID, confirm one entry/original ID; change payload and use a new ID. A reused ID with
changed payload must continue to be rejected by the existing server.

## Scroll integration

IDs must be oldest first (the existing Table query is newest first, so adapt its order).
Attach ref to the overflow-y-auto scroller and contentRef to its single list wrapper.
MessageTile supplies data-message-id. Call captureBeforeUpdate immediately before applying
list changes. The hook also captures on scroll, after layout and on ResizeObserver changes.
It preserves the first visible message and its pixel offset even when older history and
new arrivals are added in the same update. Native overflow anchoring is disabled while
mounted and restored on cleanup. No total-height guessing or double compensation.

For normal overlapping updates, arrivals are unseen IDs after the previous newest ID.
For a disjoint replacement window, the caller must supply arrivingIds from its live event
stream; history or route-loaded messages are not arrivals. Without evidence, the hook does
not label every unfamiliar ID as a new message. If the anchor was evicted, it preserves the
remaining scroll position rather than claiming exact restoration; retain the anchor in the
loaded window during history/live merges.

## Same-Table mention navigation

Use navigationTargetId for the current explicit route target and navigationKey for a new
navigation to the same ID. Normal refreshes must not change navigationKey. initialTargetId
is only the first unread/initial target. Alternatively call navigateToMessage(id) on an
explicit action: true means it is rendered and positioned; false means the caller must
load it through Plates' existing member-checked route/data path. Pending navigation finishes
when that ID appears in the rendered list. If unavailable, show the existing unavailable
notice and call cancelNavigation. Do not repeatedly fetch on ordinary live updates.

Navigation scrolls only the thread, highlights the target for 1.8 seconds and leaves focus
alone. Jump-to-latest respects reduced motion. Key the thread on Table ID, never on messages.

## Verification limits

Focused synthetic hook/event checks and TypeScript syntax checks accompany this package.
They do not replace a Next build, CSS compilation, DOM/browser accessibility checks, or
real iPhone/Android keyboard tests. No dependencies were installed and no live app was changed.
