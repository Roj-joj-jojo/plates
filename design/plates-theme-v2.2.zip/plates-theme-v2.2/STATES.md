# Plates states, with copy

Visual reference: the "Table states" and "More states" boards on the design canvas.

| State | Component | Copy and behaviour |
|---|---|---|
| Loading thread | `Skeleton` rows | Avatar circle plus three lines. `aria-busy`. The composer is usable. |
| Empty Table | custom | "No messages yet" / "Say hello, share a Plate, or ask the group a Request." Buttons: Share a Plate (primary), Ask a Request. |
| Load error | `Alert` | "Couldn't load new messages." / "Your draft is safe." Button: Try again. |
| Send: in flight | `Composer` | Field read-only, Send shows "Sending…" and is disabled. Duplicates blocked. |
| Send: sending (in thread) | `MessageTile status="sending"` | Muted text, "Sending…" (`role="status"`). No actions menu. |
| Send: failed | `Composer` error, `MessageTile status="failed"` | "Message not sent. Your message is still in the box." Retry reuses the same `clientId`. |
| Disabled | `Button disabled` | 60% opacity, no hover. Never the only way to learn something. A disabled Send always has an empty or sending reason in view. |
| Saving (Plate to Menu) | `Button disabled` | Label "Saving…". |
| Saved | `sonner` toast, `success` | "✓ Saved to your Menu". The button becomes "Saved" (outline, with check) and links to the Menu. |
| Editing | `MessageTile editing` | Field replaces text. Save / Cancel. While saving: "Saving…", both disabled. Then the tile shows "Edited". |
| Author menu | `MessageActions` | Edit, Remove. |
| Admin menu (not the author) | `MessageActions` | Remove as Admin, plus "Only {name} can edit this". |
| Everyone else | none | No actions control. |
| Remove confirmation | `ConfirmRemove` | See `COPY` in `confirm-remove.tsx`: own message, admin removal, unpublish Plate, remove share, remove Request. Confirm shows "Removing…" and stays open on failure. |
| Remove failed | `ConfirmRemove error` | Dialog stays open: "Couldn't remove this. Check your connection and try again." (pass your own text). Button reads "Try again". |
| Edit failed | `MessageTile editError` | Editor stays open: "Couldn't save. Your edit is still here." |
| Removed message | `MessageTile status="removed"` | "This message was removed." Dashed, neutral, no author or actions. |
| Removed Request or share | preview card | "This Request was removed." / "2 earlier replies stay readable. New replies are off." Link: View 2 replies. |
| Discussion after removal | `Composer closedReason` | Existing replies readable; the field is replaced by "Replies are closed. This Request was removed." |
| Unpublished Plate share | preview card | "Plate unpublished". Title and replies remain; Save to Menu is hidden. Copies already in Menus stay. |
