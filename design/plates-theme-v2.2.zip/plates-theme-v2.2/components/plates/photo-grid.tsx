import { cn } from "@/lib/utils";

export type Photo = { id: string; src: string; alt: string };

/*
 * 1 photo: one tile, 4:3, up to 320px wide.  2: two columns.  3: three columns.
 * 4 or more: four tiles; the last shows "+N" and opens the viewer for all photos.
 * Four photos use two columns until the thread column is 352px wide, so tiles stay at least 72px.
 * (Container query: it measures the column, not the screen.) Three photos need about 230px. Every photo needs alt text.
 */
export function PhotoGrid({ photos, onOpen }: { photos: Photo[]; onOpen: (index: number) => void }) {
  if (photos.length === 0) return null;
  const shown = photos.slice(0, 4);
  const extra = photos.length - shown.length;
  const single = photos.length === 1;

  return (
    <div className="@container mt-2 max-w-sm">
    <ul
      className={cn(
        "grid gap-1",
        single ? "max-w-xs grid-cols-1" : shown.length === 2 ? "grid-cols-2" : shown.length === 3 ? "grid-cols-3" : "grid-cols-2 @[22rem]:grid-cols-4",
      )}
    >
      {shown.map((p, i) => {
        const isLast = i === shown.length - 1 && extra > 0;
        return (
          <li key={p.id}>
            <button
              type="button"
              onClick={() => onOpen(i)}
              aria-label={isLast ? `Open photo ${i + 1}, and ${extra} more` : `Open photo ${i + 1}: ${p.alt}`}
              className={cn("relative block w-full overflow-hidden rounded-md bg-secondary", single ? "aspect-[4/3]" : "aspect-square")}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.src} alt={isLast ? "" : p.alt} className="size-full object-cover" loading="lazy" />
              {isLast && (
                <span className="absolute inset-0 grid place-items-center bg-foreground/70 text-sm font-bold text-background">+{extra}</span>
              )}
            </button>
          </li>
        );
      })}
    </ul>
    </div>
  );
}
