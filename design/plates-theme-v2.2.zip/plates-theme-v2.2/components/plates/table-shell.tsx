"use client";

import * as React from "react";
import { useVisualViewportVars } from "@/hooks/use-visual-viewport";

/*
 * Whole-screen frame for a Table. It is fixed to the visible area, not the layout viewport, so the
 * on-screen keyboard cannot cover the composer on iOS Safari. Only the thread scrolls; the header,
 * composer and tab bar are fixed rows of this flex column. Do not use position: fixed for the
 * composer itself.
 *
 * Fallbacks: without visualViewport support, 100dvh is used. With the Chrome and Android viewport
 * setting `interactiveWidget: "resizes-content"` the layout already resizes and these variables match it.
 */
export function TableShell({ header, thread, composer, tabs }: { header: React.ReactNode; thread: React.ReactNode; composer: React.ReactNode; tabs?: React.ReactNode }) {
  useVisualViewportVars();

  React.useEffect(() => {
    const body = document.body;
    const previous = body.style.overflow;
    body.style.overflow = "hidden"; // the page itself never scrolls; only the thread does
    return () => { body.style.overflow = previous; };
  }, []);

  return (
    <div className="fixed inset-x-0 top-[var(--vv-top,0px)] flex h-[var(--vvh,100dvh)] flex-col overflow-hidden bg-background overscroll-none">
      <div data-surface="dark" className="shrink-0">{header}</div>
      <div className="flex min-h-0 flex-1 flex-col">{thread}</div>
      <div className="shrink-0">{composer}</div>
      {tabs && <div className="shrink-0 thread:hidden">{tabs}</div>}
    </div>
  );
}
