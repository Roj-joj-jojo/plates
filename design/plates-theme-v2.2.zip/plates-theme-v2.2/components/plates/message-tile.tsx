"use client";

import * as React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { MessageActions } from "./message-actions";
import { PhotoGrid, type Photo } from "./photo-grid";
import { cn } from "@/lib/utils";

export type PlatesMessage = {
  id: string;
  author: { id: string; name: string; username: string; avatarUrl?: string };
  sentAt: string; // ISO
  editedAt?: string;
  body: string;
  photos?: Photo[];
  /** sent | sending (optimistic) | failed (not sent) | removed (placeholder only) */
  status: "sent" | "sending" | "failed" | "removed";
  unread?: boolean;
};

type Props = {
  message: PlatesMessage;
  viewerId: string;
  viewerIsAdmin: boolean;
  /** Renders links and @mentions; must wrap long URLs (see RULES.md) */
  renderBody: (body: string) => React.ReactNode;
  attachments?: React.ReactNode; // Plate or Request preview cards
  editing?: boolean;
  saving?: boolean;
  /** Shown in the editor when a save fails; the editor stays open with the text intact */
  editError?: string;
  onEdit: () => void;
  onSaveEdit: (body: string) => void;
  onCancelEdit: () => void;
  onRequestRemove: (mode: "own" | "admin") => void;
  onRetry?: () => void;
  onOpenPhoto?: (index: number) => void;
  timeLabel: string;
};

const initials = (name: string) => name.split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();

export function MessageTile(p: Props) {
  const { message: m } = p;
  // Removed content: neutral placeholder, no author, no actions
  if (m.status === "removed") {
    return (
      <article className="flex gap-3" data-message-id={m.id} aria-label="Removed message">
        <div className="size-9 shrink-0" aria-hidden />
        <p className="rounded-md border border-dashed border-input px-3 py-2 text-sm italic text-muted-foreground">This message was removed.</p>
      </article>
    );
  }

  const isAuthor = m.author.id === p.viewerId;

  return (
    <article className="flex gap-3" data-message-id={m.id} data-unread={m.unread || undefined} aria-busy={m.status === "sending" || undefined}>
      {/* 36px avatar, always a circle */}
      <Avatar className="mt-1.5 size-9 shrink-0 rounded-full">
        {m.author.avatarUrl && <AvatarImage src={m.author.avatarUrl} alt="" />}
        <AvatarFallback className="bg-secondary text-meta font-bold text-foreground">{initials(m.author.name)}</AvatarFallback>
      </Avatar>

      <div className="min-w-0 flex-1">
        {/* The header row is 44px tall because it holds the real 44px actions button. min-w-0 lets names truncate. */}
        <header className="flex min-h-11 min-w-0 items-center gap-2">
          <span className="min-w-0 max-w-[60%] truncate font-semibold" title={m.author.name}>{m.author.name}</span>
          <span className="min-w-0 shrink-[2] truncate text-meta text-muted-foreground" title={`@${m.author.username}`}>@{m.author.username}</span>
          <time dateTime={m.sentAt} className="ml-auto shrink-0 text-meta text-muted-foreground">{p.timeLabel}</time>
          {m.status !== "sending" && m.status !== "failed" && (
            <MessageActions
              authorName={m.author.name}
              viewerIsAuthor={isAuthor}
              viewerIsAdmin={p.viewerIsAdmin}
              onEdit={p.onEdit}
              onRequestRemove={p.onRequestRemove}
            />
          )}
        </header>

        {p.editing ? (
          <MessageEditor initial={m.body} saving={p.saving} error={p.editError} onSave={p.onSaveEdit} onCancel={p.onCancelEdit} />
        ) : (
          <>
            <div className={cn("whitespace-pre-wrap [overflow-wrap:anywhere]", m.status === "sending" && "text-muted-foreground")}>{p.renderBody(m.body)}</div>
            {m.editedAt && <span className="text-meta text-muted-foreground">Edited</span>}
          </>
        )}

        <PhotoGrid photos={m.photos ?? []} onOpen={(i) => p.onOpenPhoto?.(i)} />
        {p.attachments}

        {m.status === "sending" && <p className="mt-1 text-meta text-muted-foreground" role="status">Sending…</p>}
        {m.status === "failed" && (
          <div className="mt-2 flex flex-wrap items-center gap-2 rounded-md border-[1.5px] border-destructive px-3 py-2" role="alert">
            <span className="text-sm font-semibold">Message not sent.</span>
            <Button size="sm" onClick={p.onRetry}>Retry</Button>
          </div>
        )}
      </div>
    </article>
  );
}

/*
 * Mounted only while editing, so its text always starts from the current message and a
 * cancelled edit can never reappear. A live update to the message does not overwrite what
 * the person is typing.
 */
function MessageEditor({ initial, saving, error, onSave, onCancel }: { initial: string; saving?: boolean; error?: string; onSave: (body: string) => void; onCancel: () => void }) {
  const [value, setValue] = React.useState(initial);
  const unchanged = value.trim() === initial.trim();
  return (
    <div className="flex flex-col gap-2">
      <Textarea
        autoFocus
        value={value}
        readOnly={saving}
        aria-label="Edit message"
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.nativeEvent.isComposing) return;
          if (e.key === "Escape" && !saving) onCancel();
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey) && !saving && !unchanged && value.trim()) onSave(value);
        }}
        className="min-h-11 field-sizing-content"
      />
      {error && <p className="text-sm font-semibold text-destructive" role="alert">{error} Your edit is still here.</p>}
      <div className="flex gap-2">
        <Button disabled={saving || value.trim() === "" || unchanged} onClick={() => onSave(value)}>{saving ? "Saving…" : "Save"}</Button>
        <Button variant="outline" disabled={saving} onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}
