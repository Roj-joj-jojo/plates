"use client";

import { MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { DropdownMenuTrigger } from "@radix-ui/react-dropdown-menu";
import { IconButton } from "@/components/ui/icon-button";

/*
 * Who sees what:
 *   author            -> Edit, Remove
 *   Table Admin       -> Remove as Admin only (cannot rewrite another person's words)
 *   everyone else     -> no control at all
 * The confirmation dialog is opened by the parent, not rendered inside the menu,
 * so closing the menu cannot unmount the dialog.
 */
type Props = {
  authorName: string;
  viewerIsAuthor: boolean;
  viewerIsAdmin: boolean;
  onEdit: () => void;
  onRequestRemove: (mode: "own" | "admin") => void;
};

export function MessageActions({ authorName, viewerIsAuthor, viewerIsAdmin, onEdit, onRequestRemove }: Props) {
  if (!viewerIsAuthor && !viewerIsAdmin) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <IconButton label={`Actions for ${authorName}'s message`} icon={<MoreHorizontal aria-hidden />} />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52 p-1">
        {viewerIsAuthor ? (
          <>
            <DropdownMenuItem className="min-h-11 text-sm" onSelect={onEdit}>
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem className="min-h-11 text-sm text-destructive focus:text-destructive" onSelect={() => onRequestRemove("own")}>
              Remove
            </DropdownMenuItem>
          </>
        ) : (
          <>
            <DropdownMenuItem className="min-h-11 text-sm text-destructive focus:text-destructive" onSelect={() => onRequestRemove("admin")}>
              Remove as Admin
            </DropdownMenuItem>
            <DropdownMenuLabel className="text-meta font-normal text-muted-foreground">
              Only {authorName} can edit this
            </DropdownMenuLabel>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
