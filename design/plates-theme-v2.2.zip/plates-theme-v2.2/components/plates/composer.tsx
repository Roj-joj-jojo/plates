"use client";

import * as React from "react";
import { Paperclip, SendHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { IconButton } from "@/components/ui/icon-button";
import { Textarea } from "@/components/ui/textarea";

export type Member = { id: string; name: string; username: string };

/**
 * Failure contract for onSend:
 *  - resolve { ok: true }                  -> the composer clears.
 *  - resolve { ok: false, error? }, or reject/throw -> the composer keeps the text and shows the error.
 *  - clientId is an idempotency key. The same text retried after a failure reuses the same id,
 *    so the server can drop a duplicate if the first attempt actually arrived.
 */
export type SendResult = { ok: true } | { ok: false; error?: string };

type Props = {
  members: Member[];
  /** Suggestions never include this person. If Plates already has its own self-exclusion rule, keep that and drop this filter. */
  currentUserId: string;
  /** Stable signature of selected attachments. Change it when the submission payload changes. */
  submissionKey?: string;
  /** Replies are closed (removed Request or share): show a notice instead of the field */
  closedReason?: string;
  onSend: (text: string, clientId: string) => Promise<SendResult>;
  onAttach: () => void;
};

/*
 * The draft lives in this component's own state. Live updates re-render the parent freely,
 * but this component is never remounted (do not key it on message data) and the draft is
 * cleared only after a successful send.
 *
 * While a send is in flight the field is read-only, not editable, so nothing typed during the
 * wait can be lost when the send finishes. A ref guard blocks duplicate submissions from
 * double taps, Enter and button together, and slow networks.
 */
export const Composer = React.memo(function Composer({ members, currentUserId, submissionKey = "", closedReason, onSend, onAttach }: Props) {
  const [text, setText] = React.useState("");
  const [caret, setCaret] = React.useState(0);
  const [sending, setSending] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [active, setActive] = React.useState(0);
  const [dismissedStart, setDismissedStart] = React.useState<number | null>(null);
  const inFlight = React.useRef(false);
  const attempt = React.useRef<{ text: string; submissionKey: string; id: string } | null>(null);
  const ref = React.useRef<HTMLTextAreaElement>(null);
  const listId = React.useId();

  React.useEffect(() => {
    if (!inFlight.current) attempt.current = null;
  }, [submissionKey]);

  const mention = React.useMemo(() => {
    const m = /(?:^|\s)@([\w.]*)$/.exec(text.slice(0, caret));
    return m ? { query: m[1], start: caret - m[1].length - 1 } : null;
  }, [text, caret]);

  const matches = React.useMemo(() => {
    if (!mention || mention.start === dismissedStart) return [];
    const q = mention.query.toLowerCase();
    return members
      .filter((m) => m.id !== currentUserId && `${m.username} ${m.name}`.toLowerCase().includes(q))
      .slice(0, 5);
  }, [mention, dismissedStart, members, currentUserId]);

  const open = !sending && matches.length > 0;
  const activeIndex = open ? Math.min(active, matches.length - 1) : 0; // clamp: the list can shrink under the selection

  React.useEffect(() => setActive(0), [mention?.query]); // new query, back to the first result
  React.useEffect(() => {
    if (dismissedStart !== null && mention?.start !== dismissedStart) setDismissedStart(null);
  }, [mention?.start, dismissedStart]);

  function insert(m: Member) {
    if (inFlight.current || !mention) return;
    const before = `${text.slice(0, mention.start)}@${m.username} `;
    setText(before + text.slice(caret));
    setCaret(before.length);
    requestAnimationFrame(() => {
      ref.current?.focus();
      ref.current?.setSelectionRange(before.length, before.length);
    });
  }

  async function submit() {
    const value = text.trim();
    if (!value || inFlight.current) return;
    inFlight.current = true;
    setSending(true);
    setError(null);
    try {
      if (!attempt.current || attempt.current.text !== value || attempt.current.submissionKey !== submissionKey) {
        attempt.current = { text: value, submissionKey, id: crypto.randomUUID() };
      }
      const result = await onSend(value, attempt.current.id);
      if (result.ok) {
        setText("");
        setCaret(0);
        attempt.current = null;
      } else {
        setError(result.error ?? "Message not sent.");
      }
    } catch {
      setError("Message not sent.");
    } finally {
      inFlight.current = false;
      setSending(false);
    }
  }

  if (closedReason) {
    return <div className="border-t bg-background px-4 py-3 text-sm text-muted-foreground" role="status">{closedReason}</div>;
  }

  return (
    <div className="relative border-t bg-background px-4 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] thread:px-6">
      {open && (
        <ul id={listId} role="listbox" aria-label="Mention suggestions" className="absolute inset-x-4 bottom-full mb-1 max-h-[40dvh] overflow-auto rounded-md border border-input bg-popover shadow-md thread:inset-x-6">
          {matches.map((m, i) => (
            <li key={m.id} id={`${listId}-${i}`} role="option" aria-selected={i === activeIndex}>
              <button
                type="button"
                tabIndex={-1}
                disabled={sending}
                onMouseDown={(e) => e.preventDefault()} /* keep focus in the field */
                onClick={() => insert(m)}
                className={"flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm " + (i === activeIndex ? "bg-secondary" : "")}
              >
                <span className="truncate font-semibold">{m.name}</span>
                <span className="truncate text-meta text-muted-foreground">@{m.username}</span>
              </button>
            </li>
          ))}
        </ul>
      )}

      {error && <p className="mx-auto mb-2 max-w-thread text-sm font-semibold text-destructive" role="alert">{error} Your message is still in the box.</p>}

      <div className="mx-auto flex max-w-thread items-end gap-2">
        <IconButton label="Attach photo" icon={<Paperclip aria-hidden />} onClick={onAttach} disabled={sending} />
        <Textarea
          ref={ref}
          value={text}
          readOnly={sending}
          aria-busy={sending || undefined}
          rows={1}
          enterKeyHint="send"
          aria-label="Message"
          role="combobox"
          aria-expanded={open}
          aria-controls={open ? listId : undefined}
          aria-autocomplete="list"
          aria-activedescendant={open ? `${listId}-${activeIndex}` : undefined}
          placeholder="Message this Table"
          onChange={(e) => {
            if (inFlight.current) return;
            attempt.current = null;
            setText(e.target.value);
            setCaret(e.target.selectionStart);
          }}
          onSelect={(e) => setCaret(e.currentTarget.selectionStart)}
          onKeyDown={(e) => {
            if (inFlight.current || e.nativeEvent.isComposing) return; // IME input: Enter confirms the composition
            if (open) {
              if (e.key === "ArrowDown") { e.preventDefault(); setActive((activeIndex + 1) % matches.length); return; }
              if (e.key === "ArrowUp") { e.preventDefault(); setActive((activeIndex - 1 + matches.length) % matches.length); return; }
              if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); insert(matches[activeIndex]); return; }
              if (e.key === "Escape") { e.preventDefault(); if (mention) setDismissedStart(mention.start); return; }
            }
            if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); void submit(); }
          }}
          className="max-h-36 min-h-11 flex-1 resize-none border-[1.5px] border-input field-sizing-content"
        />
        <Button onClick={() => void submit()} disabled={sending || text.trim() === ""} aria-label={sending ? "Sending" : "Send message"}>
          {sending ? "Sending…" : (<><SendHorizontal aria-hidden /> Send</>)}
        </Button>
      </div>
    </div>
  );
});
