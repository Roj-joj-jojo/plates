const assert = require("node:assert/strict");
const vm = require("node:vm");
const tick = require("node:timers/promises").setImmediate;

function hooks() {
  const slots = [];
  let index = 0;
  let effects = [];
  const same = (a, b) => a && b && a.length === b.length && a.every((v, i) => Object.is(v, b[i]));
  const memo = (make, deps) => {
    const i = index++;
    if (!slots[i] || !same(slots[i].deps, deps)) slots[i] = { value: make(), deps };
    return slots[i].value;
  };
  const effect = (fn, deps) => {
    const i = index++;
    if (!slots[i] || !same(slots[i].deps, deps)) {
      const old = slots[i];
      effects.push(() => { old?.cleanup?.(); slots[i] = { deps, cleanup: fn() }; });
    }
  };
  const react = {
    memo: (fn) => fn,
    useRef: (value) => memo(() => ({ current: value }), []),
    useState: (value) => {
      const i = index++;
      if (!slots[i]) slots[i] = { value };
      return [slots[i].value, (next) => { slots[i].value = typeof next === "function" ? next(slots[i].value) : next; }];
    },
    useId: () => memo(() => "mention-list", []),
    useMemo: memo,
    useCallback: (fn, deps) => memo(() => fn, deps),
    useEffect: effect,
    useLayoutEffect: effect,
  };
  return { react, render: (fn) => { index = 0; return fn(); },
    commit: () => { const pending = effects; effects = []; pending.forEach((fn) => fn()); },
    cleanup: () => slots.forEach((s) => s.cleanup?.()) };
}

function load(source, filename, ts, env) {
  const exports = {};
  const runtime = { jsx: (type, props) => ({ type, props }), jsxs: (type, props) => ({ type, props }) };
  const code = ts.transpileModule(source, { fileName: filename, compilerOptions: {
    target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX, module: ts.ModuleKind.CommonJS,
  } }).outputText;
  vm.runInNewContext(code, { exports, require: (name) => {
    if (name === "react") return env.react;
    if (name === "react/jsx-runtime") return runtime;
    if (name.includes("textarea")) return { Textarea: "Textarea" };
    if (name.includes("icon-button")) return { IconButton: "IconButton" };
    if (name.includes("button")) return { Button: "Button" };
    if (name === "lucide-react") return { Paperclip: "Paperclip", SendHorizontal: "SendHorizontal" };
    throw Error("Unexpected import: " + name);
  }, crypto: { randomUUID: env.uuid }, requestAnimationFrame: (fn) => { fn(); return 1; },
    CSS: { escape: (s) => s }, window: env.window, ResizeObserver: env.ResizeObserver,
    setTimeout: () => 1, clearTimeout: () => {} }, { timeout: 3000 });
  return exports;
}
function nodes(tree) {
  if (!tree || typeof tree !== "object") return [];
  if (Array.isArray(tree)) return tree.flatMap(nodes);
  return [tree, ...nodes(tree.props?.children)];
}

async function runFocusedChecks(readSource, ts) {
  const passed = [];
  const h = hooks();
  let serial = 0, resolveSend;
  const calls = [];
  const props = { members: [{ id: "me", name: "Self", username: "self" }, { id: "peer", name: "Peer", username: "peer" }],
    currentUserId: "me", onAttach: () => {}, onSend: (text, id) => {
      calls.push({ text, id }); return new Promise((resolve) => { resolveSend = resolve; });
    } };
  const Composer = load(readSource("components/plates/composer.tsx"), "composer.tsx", ts,
    { react: h.react, uuid: () => "attempt-" + ++serial }).Composer;
  const render = () => { const tree = h.render(() => Composer(props)); h.commit(); return tree; };
  let tree = render();
  const field = (t) => nodes(t).find((n) => n.type === "Textarea");
  const send = (t) => nodes(t).find((n) => n.type === "Button");
  field(tree).props.onChange({ target: { value: "@", selectionStart: 1 } });
  tree = render();
  const staleField = field(tree);
  const staleSuggestion = nodes(tree).find((n) => n.type === "button");
  assert(staleSuggestion);
  send(tree).props.onClick();
  staleSuggestion.props.onClick();
  staleField.props.onKeyDown({ key: "Enter", nativeEvent: { isComposing: false }, preventDefault() {} });
  staleField.props.onChange({ target: { value: "lost text", selectionStart: 9 } });
  send(tree).props.onClick();
  tree = render();
  assert.equal(calls.length, 1);
  assert.equal(field(tree).props.value, "@");
  assert.equal(field(tree).props.readOnly, true);
  assert.equal(nodes(tree).some((n) => n.props?.role === "listbox"), false);
  passed.push("Pending send blocks stale mention clicks, keyboard insertion, field changes and duplicate submits");
  resolveSend({ ok: false, error: "Response lost" });
  await tick();
  tree = render();
  assert.equal(field(tree).props.value, "@");
  send(tree).props.onClick();
  assert.equal(calls[1].id, calls[0].id);
  resolveSend({ ok: false }); await tick();
  tree = render();
  field(tree).props.onChange({ target: { value: "changed", selectionStart: 7 } });
  tree = render(); send(tree).props.onClick();
  assert.notEqual(calls[2].id, calls[1].id);
  resolveSend({ ok: false }); await tick();
  props.submissionKey = "new-photo-selection";
  tree = render(); send(tree).props.onClick();
  assert.notEqual(calls[3].id, calls[2].id);
  resolveSend({ ok: true }); await tick();
  tree = render(); assert.equal(field(tree).props.value, "");
  passed.push("Failed send retains text/ID; text or attachment changes use a new ID; success clears text");

  const s = hooks();
  let ids = Array.from({ length: 20 }, (_, i) => "m" + i);
  let height = 300, position = 0, reduced = false;
  let observer;
  const listeners = {};
  const attributes = new Map();
  const row = (id) => ({ dataset: { messageId: id },
    getBoundingClientRect: () => ({ top: ids.indexOf(id) * 100 - position, bottom: (ids.indexOf(id) + 1) * 100 - position, height: 100 }),
    setAttribute: (k, v) => attributes.set(id + ":" + k, v), removeAttribute: (k) => attributes.delete(id + ":" + k) });
  const el = { style: { overflowAnchor: "auto" }, clientTop: 0,
    get clientHeight() { return height; }, get scrollHeight() { return ids.length * 100; },
    get scrollTop() { return position; }, set scrollTop(v) { position = Math.max(0, Math.min(v, this.scrollHeight - height)); },
    getBoundingClientRect: () => ({ top: 0 }), querySelectorAll: () => ids.map(row),
    querySelector: (selector) => { const id = selector.match(/="([^"]+)"/)[1]; return ids.includes(id) ? row(id) : null; },
    addEventListener: (type, fn) => { listeners[type] = fn; }, removeEventListener: (type) => { delete listeners[type]; },
    scrollTo(value) { this.lastBehavior = value.behavior; this.scrollTop = value.top; } };
  class Observer { constructor(fn) { this.fn = fn; observer = this; } observe() {} disconnect() {} }
  const Hook = load(readSource("hooks/use-thread-scroll.ts"), "use-thread-scroll.ts", ts,
    { react: s.react, ResizeObserver: Observer, window: { matchMedia: () => ({ matches: reduced }) } }).useThreadScroll;
  let options = {};
  const renderScroll = () => { const result = s.render(() => Hook(ids, options)); result.ref.current = el; result.contentRef.current = {}; s.commit(); return result; };
  let result = renderScroll();
  assert.equal(position, 1700); assert.equal(el.style.overflowAnchor, "none");
  position = 450; listeners.scroll(); result.captureBeforeUpdate();
  ids = ["older-a", "older-b", ...ids, "live-1"];
  result = renderScroll(); result = renderScroll();
  assert.equal(position, 650); assert.equal(result.unseen, 1);
  passed.push("Combined prepend/live append keeps the visible message offset and counts only the arrival");
  height = 240; observer.fn(); assert.equal(position, 650);
  passed.push("Composer resize preserves a reader's anchor");
  options = { navigationTargetId: "m10", navigationKey: 1 };
  result = renderScroll(); assert.equal(attributes.get("m10:data-mention-target"), "true");
  const targetPosition = position;
  position = 0; listeners.scroll();
  options = { navigationTargetId: "m10", navigationKey: 2 };
  result = renderScroll(); assert.equal(position, targetPosition);
  assert.equal(result.navigateToMessage("missing"), false);
  ids = [...ids, "missing"]; result = renderScroll();
  assert.equal(attributes.get("missing:data-mention-target"), "true");
  passed.push("Same-Table and repeated-target navigation works; a missing target completes after loading");
  position = 200; listeners.scroll();
  ids = ["historical-x", "historical-y", "historical-z"];
  options = {}; result = renderScroll(); result = renderScroll();
  assert.equal(result.unseen, 0);
  passed.push("Disjoint history window does not invent live arrivals");
  height = 100; position = 0; listeners.scroll();
  ids = ["live-x", "live-y", "live-z", "live-w"];
  options = { arrivingIds: ["live-z", "live-w"] };
  result = renderScroll(); result = renderScroll();
  assert.equal(result.unseen, 2);
  passed.push("Disjoint live replacement counts only explicitly supplied arrivals");
  result.scrollToBottomNow();
  ids = [...ids, "live-next"]; options = {};
  result = renderScroll();
  assert.equal(position, el.scrollHeight - el.clientHeight);
  passed.push("A reader at the bottom follows a new arrival");
  reduced = true; result.jumpToLatest(); assert.equal(el.lastBehavior, "auto");
  s.cleanup(); assert.equal(el.style.overflowAnchor, "auto");
  passed.push("Reduced-motion jump is immediate and native anchoring is restored on cleanup");
  return passed;
}
module.exports = { runFocusedChecks };
if (require.main === module) {
  const fs = require("node:fs"); const path = require("node:path"); const ts = require("typescript");
  runFocusedChecks((name) => fs.readFileSync(path.join(__dirname, "..", name), "utf8"), ts)
    .then((passed) => passed.forEach((name) => console.log("PASS " + name)))
    .catch((error) => { console.error(error); process.exitCode = 1; });
}
